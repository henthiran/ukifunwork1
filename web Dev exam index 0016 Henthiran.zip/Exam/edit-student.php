<?php
require_once "config.php";

//After form submit
if(isset($_POST['submit'])){

  $name = $_POST['name'];
  $contact = $_POST['contact'];
  $gender  = $_POST['gender'];
  $address = $_POST['address'];
  $subject = $_POST['subject'];
  $id = $_POST['id'];

  $sql = "UPDATE `tbl_student` SET `name`='$name',`contact`='$contact',`gender`='$gender',`address`='$address',`subject`='$subject' WHERE id=$id";
  $result = $conn->query($sql);

  if($result){header('Location: ./index.php');}

}

?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Form</title>
</head>

<body>
    <?php

  //Check if ID is provided or not.
  if(isset($_GET['id'])){
    $student_id = $_GET['id'];
    $sql = "SELECT * FROM tbl_student WHERE id=$student_id";
    $result = $conn->query($sql);
    //Check the results found or not
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()){
  ?>
    <form action="" method="POST">
        <fieldset style="width:350px">
            <legend>Personal Info:</legend>

            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" required><br><br>

            <label for="contact">Contact:</label>
            <input type="text" id="contact" name="contact" value="<?php echo $row['contact']; ?>" required><br><br>

            <input type="radio" id="male" name="gender" value="Male" <?php if($row['gender']=='Male') echo 'checked';?>>
            <label for="male">Male</label>
            <input type="radio" id="female" name="gender" value="Female"
                <?php if($row['gender']=='Female') echo 'checked';?>>
            <label for="female">Female</label>
            <input type="radio" id="other" name="gender" value="Other"
                <?php if($row['gender']=='Other') echo 'checked';?>>
            <label for="other">Other</label> <br><br>

            <label for="">Address:</label>
            <textarea name="address" id="address" rows="2" cols="20"
                required><?php echo $row['address']; ?></textarea><br><br>

            <label for="">Subject:</label>
            <select name="subject" id="">
                <option value="Subject 1" <?php if($row['subject']=='Subject 1') echo 'selected';?>>Subject 1</option>
                <option value="Subject 2" <?php if($row['subject']=='Subject 2') echo 'selected';?>>Subject 2</option>
                <option value="Subject 3" <?php if($row['subject']=='Subject 3') echo 'selected';?>>Subject 3</option>
                <option value="Subject 4" <?php if($row['subject']=='Subject 4') echo 'selected';?>>Subject 4</option>
            </select><br><br>
            <input type="submit" name="submit" value="Submit">
            <input type="reset" value="Reset">
            <?php
        }//End of if isset ID
      }//End of if result > 0
    }// End of while
  ?>

        </fieldset>
    </form>
</body>

</html>