<?php
require_once "config.php";
$sql = "SELECT * FROM tbl_student";
$result = $conn->query($sql);
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Informations</title>
    <style>
        table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
        }

        td{
            padding: 8px;
        }
</style>
</head>
<body>
    <h1>Student Information</h1>
    <hr>
    <a href="new-student.php">Add New Student</a>
    <br>
    <br>
    <table>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Subject</th>
            <th>Edit</th>
        </tr>
        <?php 
        if($result->num_rows>0){
            $num = 0;
            while($row=$result->fetch_assoc()){
            $num +=1; // Serial Number
        ?>
        <tr>
            <td><?php echo $num;?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['contact']; ?></td>
            <td><?php echo $row['gender']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['subject']; ?></td>
            <td><a href="edit-student.php?id=<?php echo $row['id']; ?>">EDIT</a></td>
        </tr>
        <?php }}
        else{
            echo '<tr><td colspan="7">No records Found</td></tr>';
        } ?>
    </table>
</body>
</html>