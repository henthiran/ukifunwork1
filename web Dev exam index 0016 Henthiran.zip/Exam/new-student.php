<?php
require_once "config.php";

//After form submit
if(isset($_POST['submit'])){

  $name = $_POST['name'];
  $contact = $_POST['contact'];
  $gender  = $_POST['gender'];
  $address = $_POST['address'];
  $subject = $_POST['subject'];

  $sql = "INSERT INTO `tbl_student`(`name`, `contact`, `gender`, `address`, `subject`) VALUES ('$name','$contact','$gender','$address','$subject')";
  $result = $conn->query($sql);

  if($result){header('Location: ./index.php');}

}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Form</title>
</head>
<body>
<form action="" method="POST">
 <fieldset style="width:350px">
  <legend>Personal Info:</legend>
  <label for="fname">Name:</label>
  <input type="text" id="fname" name="name" required><br><br>
  <label for="contact">Contact:</label>
  <input type="text" id="contact" name="contact" required><br><br>
  
  <input type="radio" id="male" name="gender" value="Male" checked>
  <label for="male">Male</label>
  <input type="radio" id="female" name="gender" value="Female">
  <label for="female">Female</label>
  <input type="radio" id="other" name="gender" value="Other">
  <label for="other">Other</label> <br><br>

  <label for="">Address:</label>
  <textarea name="address" id="address" rows="2" cols="20" required></textarea><br><br>
  <label for="">Subject:</label>
<select name="subject" id="">
    <option value="Subject 1">Subject 1</option>
    <option value="Subject 2">Subject 2</option>
    <option value="Subject 3" selected>Subject 3</option>
    <option value="Subject 4">Subject 4</option>
</select><br><br>
  <input type="submit" name="submit" value="Submit">
  <input type="reset" value="Reset">

 </fieldset>
</form>
</body>
</html>